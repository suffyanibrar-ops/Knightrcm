import { NextResponse } from "next/server";
import { isAdminAuthenticated } from "@/lib/auth";
import { insertSubmission, isSqliteAvailable, listSubmissions, sqliteStatus } from "@/lib/sqlite";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * Embedded SQLite submissions endpoint (plain SQL, no ORM).
 *
 * POST  — validate → insert with a parameterized statement
 * GET   — admin-only listing (used by the admin panel / CSV export)
 */

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const LIMITS = {
  name: 120,
  email: 200,
  phone: 40,
  practice: 200,
  specialty: 120,
  practiceSize: 80,
  providers: 80,
  interest: 120,
  interests: 12,
  message: 4000,
  source: 120,
} as const;

function text(value: unknown, max: number): string {
  if (value === null || value === undefined) return "";
  return String(value).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").trim().slice(0, max);
}

export async function POST(request: Request) {
  if (!isSqliteAvailable()) {
    const status = sqliteStatus();
    console.error("[submissions] SQLite unavailable:", status.error);
    return NextResponse.json(
      { ok: false, error: "The local database is not writable on this host. Please call (812) 994-0046 or email admin@knightmedicalbilling.com." },
      { status: 503 },
    );
  }

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request body." }, { status: 400 });
  }

  const name = text(body.name, LIMITS.name);
  const email = text(body.email, LIMITS.email).toLowerCase();
  const phone = text(body.phone, LIMITS.phone);
  const practice = text(body.practice ?? body.facility, LIMITS.practice);
  const specialty = text(body.specialty, LIMITS.specialty);
  const practiceSize = text(body.practiceSize ?? body.facilityType, LIMITS.practiceSize);
  const providers = text(body.providers ?? body.providerCount ?? body.monthlyCollections, LIMITS.providers);
  const message = text(body.message, LIMITS.message);
  const source = text(body.source, LIMITS.source) || "schedule-form";

  const rawInterests = Array.isArray(body.interests) ? body.interests : [];
  const interests = rawInterests
    .slice(0, LIMITS.interests)
    .map((item) => text(item, LIMITS.interest))
    .filter(Boolean);

  const errors: Record<string, string> = {};
  if (name.length < 2) errors.name = "Please enter your name (at least 2 characters).";
  if (!EMAIL_PATTERN.test(email)) errors.email = "Please enter a valid email address.";
  if (specialty.length === 0 && Array.isArray(body.interests) && body.interests.length === 0) {
    // Specialty is required on the consultation form but optional on generic forms.
    if (practice.length > 0) errors.specialty = "Please choose a specialty.";
  }

  if (Object.keys(errors).length > 0) {
    return NextResponse.json({ ok: false, error: Object.values(errors)[0], errors }, { status: 400 });
  }

  const result = insertSubmission({
    name,
    email,
    phone: phone || null,
    practice: practice || null,
    specialty: specialty || null,
    practiceSize: practiceSize || null,
    providers: providers || null,
    interests,
    message: message || null,
    source,
  });

  if (!result.ok) {
    return NextResponse.json({ ok: false, error: result.error ?? "Could not save your submission." }, { status: 500 });
  }

  return NextResponse.json({ ok: true, id: result.id, message: "Your submission was saved." }, { status: 201 });
}

export async function GET(request: Request) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }
  const query = new URL(request.url).searchParams.get("q") ?? "";
  const rows = listSubmissions({ query: query || undefined });
  return NextResponse.json({ ok: true, count: rows.length, submissions: rows }, { headers: { "Cache-Control": "no-store" } });
}
